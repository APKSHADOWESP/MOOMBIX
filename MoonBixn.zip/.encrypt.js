const crypto = require('crypto');
const fs = require('fs');

fs.readFile('.pg.txt', 'utf8', (err, data) => {
    if (err) {
        console.error(err);
        return;
    }
    
    const lines = data.split('\n');
    
    const payload = lines[0].trim();
    const game_tag = lines[1].trim();

    function encrypt(payload, game_tag) {
        const iv = Buffer.from([0x6d, 0x77, 0x91, 0xf5, 0x8d, 0x12, 0x59, 0x11, 0xf7, 0x6a, 0xb6, 0x51]);
        const ivBase64 = iv.toString('base64');
        const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(game_tag), ivBase64.slice(0, 16));
        let encrypted = cipher.update(payload, 'utf8', 'base64');
        encrypted += cipher.final('base64');
        return ivBase64 + encrypted;
    }

    const encrypted_payload = encrypt(payload, game_tag);

    fs.writeFile('.ep.txt', encrypted_payload, (err) => {
        if (err) {
            console.error(err);
            return;
        }
    });
});